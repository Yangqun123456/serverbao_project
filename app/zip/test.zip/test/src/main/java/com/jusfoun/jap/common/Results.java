/**
 * 
 */
package com.jusfoun.jap.common;

import com.itmuch.core.web.converter.Result;

/**
 * @author wcq
 *
 */
public class Results  extends Result{
private String workTableId ;

/**
 * @return the workTableId
 */
public String getWorkTableId() {
	return workTableId;
}

/**
 * @param workTableId the workTableId to set
 */
public void setWorkTableId(String workTableId) {
	this.workTableId = workTableId;
}
}
