package com.jusfoun.jap.hive.mapper;

import com.jusfoun.jap.hive.domain.CubeHiveTableRelation;
import tk.mybatis.mapper.common.Mapper;

public interface CubeHiveTableRelationMapper extends Mapper<CubeHiveTableRelation> {
}