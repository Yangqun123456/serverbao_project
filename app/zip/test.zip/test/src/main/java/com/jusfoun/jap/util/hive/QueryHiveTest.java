package com.jusfoun.jap.util.hive;

public class QueryHiveTest {

//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		 String tablename="kylin_sales";
//
//         QueryHiveUtils.getAll(tablename);
//	}

}
