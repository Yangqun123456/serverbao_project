package com.jusfoun.jap.workTable.vo;

import java.util.List;

import com.jusfoun.jap.workTable.domain.ColumnChinese;

public class ColumnChineseList {
	private List<ColumnChinese> columnChineseList;

	public List<ColumnChinese> getColumnChineseList() {
		return columnChineseList;
	}

	public void setColumnChineseList(List<ColumnChinese> columnChineseList) {
		this.columnChineseList = columnChineseList;
	}
}