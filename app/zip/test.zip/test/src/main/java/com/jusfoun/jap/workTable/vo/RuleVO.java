package com.jusfoun.jap.workTable.vo;

public class RuleVO {
	private String factTableRule;
	private String ruleName;
	public String getFactTableRule() {
		return factTableRule;
	}
	public void setFactTableRule(String factTableRule) {
		this.factTableRule = factTableRule;
	}
	public String getRuleName() {
		return ruleName;
	}
	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}

}
