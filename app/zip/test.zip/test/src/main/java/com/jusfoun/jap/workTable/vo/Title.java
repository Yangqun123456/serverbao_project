/**
 * 
 */
package com.jusfoun.jap.workTable.vo;

/**
 * @author Rain
 *
 */
public class Title {
	private String text;
	private String left;
	
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public String getLeft() {
		return left;
	}
	public void setLeft(String left) {
		this.left = left;
	}
	

}
